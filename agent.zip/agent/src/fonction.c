#include <stdlib.h>
#include <stdio.h>
#include<string.h>
#include "fonction.h"

void ajout(char *agents, agent a)
{
    FILE *f = fopen(agents, "a+");
    if (f == NULL)
    {
        printf("Error \n");
        return;
    }

    strcpy(a.park, "NULL");

    fprintf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d\n", 
            a.id_agent, a.nom_agent, a.prenom_agent, a.sexe_agent, 
            a.sal_agent, a.type_contact, a.contact, a.moyen_agent, 
            a.park, a.fonction_agent, a.date_agent.j, a.date_agent.m, a.date_agent.a);

    fclose(f);
}

int verify(char *agents, char *id)
{
    int t = 0;
    agent a;

    FILE *f = fopen(agents, "r");
    if (f == NULL)
    {
        printf("Error");
        return 0;
    }

    while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
    {
        if (strcmp(id, a.id_agent) == 0)
        {
            t = 1;
            break;
        }
    }

    fclose(f);
    return t;
}

void sexe (char msg[],int choix)
{
if(choix==1)
{
strcpy(msg,"male");
}
else
{
strcpy(msg,"female");
}
}

void moyen(char msg[], int choix[]) {
      

    if (choix[0] == 1) {
        strcpy(msg, "voiture");
        
    }
    if (choix[1] == 1) {
        
            strcat(msg, "_moto"); 
        
    }
    if (choix[2] == 1) {
        
            strcat(msg, "_aucun"); 
       
        
    }
}


void supp_agent(char *agents,char *temp_agents,char c[])
		{

		
			FILE *f = fopen(agents, "r");  
    			if (f == NULL) {
        		printf("erreur \n");
        		return;
    			}
			FILE *f1 = fopen(temp_agents, "w");
			if (f1 == NULL) {
        		printf("erreur \n");
        		return;
    			}
			agent a;
			
		while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
			{
       
			if(strcmp(c,a.id_agent)!=0)	
							{
				fprintf(f1, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d\n", 
            a.id_agent, a.nom_agent, a.prenom_agent, a.sexe_agent, 
            a.sal_agent, a.type_contact, a.contact, a.moyen_agent, 
            a.park, a.fonction_agent, a.date_agent.j, a.date_agent.m, a.date_agent.a);
    							}

				}
			
			
			fclose(f);
			fclose(f1);
			
			remove(agents);
			rename(temp_agents,agents);
			
			
			
			
		

			
		
			}
