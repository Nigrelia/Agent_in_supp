#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int choix=1;
int choix1[]={0,0,0,0};


void
on_ajout_agent_b_clicked               (GtkWidget       *button,
                                        gpointer         user_data)
{
    GtkWidget *id_agent_e;
    GtkWidget *nom_agent_e;
    GtkWidget *prenom_agent_e;
    GtkWidget *contact_agent_e;
    GtkWidget *fonction_agent_e;
    GtkWidget *sal_agent_e;
    GtkWidget *ajout_agent_res;
	GtkWidget * type_agent_c;
	GtkWidget * jour_agent_sb;
	GtkWidget * mois_agent_sb;
	GtkWidget * year_agent_sb;
	

    int veri;
    agent a;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id déjà existe</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Agent ajouté avec succès</span>";
    

    id_agent_e = lookup_widget(button, "id_agent_e");
    nom_agent_e = lookup_widget(button, "nom_agent_e");
    prenom_agent_e = lookup_widget(button, "prenom_agent_e");
    contact_agent_e = lookup_widget(button, "contact_agent_e");
    fonction_agent_e = lookup_widget(button, "fonction_agent_e");
    sal_agent_e = lookup_widget(button, "sal_agent_e");
    ajout_agent_res = lookup_widget(button, "ajout_agent_res");
	type_agent_c = lookup_widget(button,"type_agent_c");

	jour_agent_sb = lookup_widget(button,"jour_agent_sb");
	mois_agent_sb = lookup_widget(button,"mois_agent_sb");
	year_agent_sb = lookup_widget(button,"year_agent_sb");



	
    strcpy(a.id_agent, gtk_entry_get_text(GTK_ENTRY(id_agent_e)));
    strcpy(a.nom_agent, gtk_entry_get_text(GTK_ENTRY(nom_agent_e)));
    strcpy(a.prenom_agent, gtk_entry_get_text(GTK_ENTRY(prenom_agent_e)));
    strcpy(a.contact, gtk_entry_get_text(GTK_ENTRY(contact_agent_e)));
    strcpy(a.fonction_agent, gtk_entry_get_text(GTK_ENTRY(fonction_agent_e)));
    strcpy(a.sal_agent, gtk_entry_get_text(GTK_ENTRY(sal_agent_e)));
	sexe(a.sexe_agent,choix);
	moyen(a.moyen_agent,choix1);
	strcpy(a.type_contact, gtk_combo_box_get_active_text(GTK_COMBO_BOX(type_agent_c)));
	a.date_agent.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_agent_sb));
	a.date_agent.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_agent_sb));
	a.date_agent.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(year_agent_sb));
		


	
    

    veri = verify("agents.txt", a.id_agent);
    if (veri == 0) 
    {
        ajout("agents.txt", a);
        gtk_label_set_markup(GTK_LABEL(ajout_agent_res), res2);
    } 
    else 
    {
        gtk_label_set_markup(GTK_LABEL(ajout_agent_res), res1);
    }
}




void
on_mod_agent_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_chercher_agent_b_clicked            (GtkWidget       *button,
                                        gpointer         user_data)
{
	GtkWidget *chercher_agent_e , *chercher_agent_res;
	
	GtkWidget *nom_agent_mod_e;
	GtkWidget *prenom_agent_mod_e;
	GtkWidget *contact_agent_mod_e;
	GtkWidget *fonction_agent_mod_e;
	GtkWidget *salaire_agent_mod_e;
	
	GtkWidget * type_agent_mod_c;
	GtkWidget * jour_agent_mod_sb;
	GtkWidget * mois_agent_mod_sb;
	GtkWidget * year_agent_mod_sb;


	GtkWidget *mod_agent_male;
	GtkWidget *mod_agent_female;	



int veri;
    agent a;
    char res1[200] = "<span foreground='red' font_weight='bold'>L'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Agent Trouvé</span>";
	char x [20];
	

	chercher_agent_e = lookup_widget(button, "chercher_agent_e");
    	nom_agent_mod_e = lookup_widget(button, "nom_agent_mod_e");
    	prenom_agent_mod_e = lookup_widget(button, "prenom_agent_mod_e");
    	contact_agent_mod_e = lookup_widget(button, "contact_agent_mod_e");
    	fonction_agent_mod_e = lookup_widget(button, "fonction_agent_mod_e");
    	salaire_agent_mod_e = lookup_widget(button, "salaire_agent_mod_e");
    	chercher_agent_res = lookup_widget(button, "chercher_agent_res");
	type_agent_mod_c = lookup_widget(button,"type_agent_mod_c");
	
	jour_agent_mod_sb = lookup_widget(button,"jour_agent_mod_sb");
	mois_agent_mod_sb = lookup_widget(button,"mois_agent_mod_sb");
	year_agent_mod_sb = lookup_widget(button,"year_agent_mod_sb");
	
	mod_agent_male = lookup_widget(button, "mod_agent_male");
	mod_agent_female = lookup_widget(button, "mod_agent_female");


	strcpy(x, gtk_entry_get_text(GTK_ENTRY(chercher_agent_e)));


veri=verify("agents.txt", x);
if (veri==0)
{
gtk_label_set_markup(GTK_LABEL(chercher_agent_res), res1);
}
	FILE *f = fopen("agents.txt", "r");  
    			if (f == NULL) {
        		printf("erreur \n");
        		return;
    			}
else
{
	while (fscanf(f, "%s %s %s %s %s %s %s %s %s %s %d-%d-%d", 
                  a.id_agent, 
                  a.nom_agent, 
                  a.prenom_agent, 
                  a.sexe_agent, 
                  a.sal_agent, 
                  a.type_contact, 
                  a.contact, 
                  a.moyen_agent, 
                  a.park, 
                  a.fonction_agent, 
                  &a.date_agent.j, 
                  &a.date_agent.m, 
                  &a.date_agent.a) != EOF)
	


	{
	if(strcmp(x,a.id_agent)==0)
	{
	gtk_entry_set_text(GTK_ENTRY(nom_agent_mod_e), a.nom_agent);
	gtk_entry_set_text(GTK_ENTRY(prenom_agent_mod_e), a.prenom_agent);
	gtk_entry_set_text(GTK_ENTRY(salaire_agent_mod_e), a.sal_agent);
	gtk_entry_set_text(GTK_ENTRY(fonction_agent_mod_e), a.fonction_agent);
	gtk_entry_set_text(GTK_ENTRY(contact_agent_mod_e), a.contact);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(jour_agent_mod_sb),a.date_agent.j);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(mois_agent_mod_sb),a.date_agent.m);
	gtk_spin_button_set_value(GTK_SPIN_BUTTON(year_agent_mod_sb),a.date_agent.a);	
	if (strcmp(a.type_contact, "Téléphone") == 0) 
	{
    	gtk_combo_box_set_active(GTK_COMBO_BOX(type_agent_mod_c), 0); 
	} 
	if (strcmp(a.type_contact, "Email") == 0) 
	{
    	gtk_combo_box_set_active(GTK_COMBO_BOX(type_agent_mod_c), 1); 
	}
	
	if (strcmp(a.sexe_agent, "male") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_agent_male), TRUE);
	
	} 
	else if (strcmp(a.sexe_agent, "female") == 0) 
	{
    	gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(mod_agent_female), TRUE);
	
	}

	

	 
	}
	}










}



}











void
on_supp_agent_b_clicked                (GtkWidget       *button,
                                        gpointer         user_data)
{
char res1[200] = "<span foreground='red' font_weight='bold'>l'id n'existe pas</span>";
    char res2[200] = "<span foreground='green' font_weight='bold'>Suppression avec succès</span>";
int t;
agent a;
GtkWidget *supp_agent_e;
GtkWidget *supp_agent_res;
supp_agent_e = lookup_widget(button, "supp_agent_e");
supp_agent_res = lookup_widget(button, "supp_agent_res");
strcpy(a.id_agent, gtk_entry_get_text(GTK_ENTRY(supp_agent_e)));
t=verify("agents.txt",a.id_agent);
//supp_agent_res
if(t==1)
{
supp_agent("agents.txt","temp_agents.txt",a.id_agent);
gtk_label_set_markup(GTK_LABEL(supp_agent_res), res2);
}
else
{
gtk_label_set_markup(GTK_LABEL(supp_agent_res), res1);
}


}


void
on_aff_liste_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data)
{

}


void
on_sexe_agent_male_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 1;


}


void
on_sexe_agent_female_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 2;

}


void
on_mod_agent_male_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 1;

}


void
on_mod_agent_female_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(togglebutton)))
    choix = 2;
}


void on_voiture_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[0] = 1;
    } else {
        choix1[0] = 0;
    }
}

void on_aucun_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[2] = 1;
    } else {
        choix1[2] = 0;
    }
}

void on_moto_agent_cb_toggled(GtkToggleButton *togglebutton, gpointer user_data) {
    if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[1] = 1;
    } else {
        choix1[1] = 0;
    }
}



void
on_mod_voiture_agent_cb_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[0] = 1;
    } else {
        choix1[0] = 0;
    }

}


void
on_moto_agent_mod_cb_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
	if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[1] = 1;
    } else {
        choix1[1] = 0;
    }

}


void
on_aucun_agent_mod_cb_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

 if (gtk_toggle_button_get_active(togglebutton)) {
        choix1[2] = 1;
    } else {
        choix1[2] = 0;
    }

}

