#include <gtk/gtk.h>


void
on_ajout_agent_b_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_mod_agent_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_chercher_agent_b_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supp_agent_b_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_aff_liste_b_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_sexe_agent_male_toggled             (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_sexe_agent_female_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_agent_male_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_agent_female_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_voiture_agent_cb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_cb_clicked               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_cb_clicked              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_voiture_agent_cb_clicked        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_mod_cb_clicked           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_mod_cb_clicked          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_voiture_agent_cb_toggled            (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_cb_toggled              (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_cb_toggled               (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_mod_voiture_agent_cb_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_moto_agent_mod_cb_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_aucun_agent_mod_cb_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
