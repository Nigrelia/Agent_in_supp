#ifndef FONCTION_H
#define FONCTION_H

typedef struct
{
int j;
int m;
int a;
}date;


typedef struct
{

char id_agent[20];
char nom_agent[20];
char prenom_agent[20];
char sexe_agent[10];
char sal_agent[20];
char type_contact[20];
char contact[20];
char moyen_agent[20];
char park[20];
char fonction_agent[20];
date date_agent;
} agent ;

void ajout(char *agents, agent a);
int verify(char *agents, char *id);
void sexe (char msg[],int choix);
void moyen (char msg[],int choix[]);
void supp_agent(char *agents,char *temp_agents,char c[]);



#endif
